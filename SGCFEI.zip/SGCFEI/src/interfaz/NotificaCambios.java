package interfaz;

public interface NotificaCambios {
    
    public void refrescaTabla(boolean carga);
    
}
